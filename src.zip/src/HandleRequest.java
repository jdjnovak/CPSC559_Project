import java.net.*;

public class HandleRequest implements Runnable {
    public void HandleSnip(String noun) {
	}

	public void HandleStop() {
	}

	public void HandlePeer(String noun) {

	}
}
